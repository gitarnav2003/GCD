import math

print("The gcd of 60 and 48 is : ", end="")
print(math.gcd(60, 48))
